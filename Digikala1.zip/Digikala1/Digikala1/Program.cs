﻿using Digikala1.Model;
using Digikala1.Operations;

string address = @"D:\Shamsipoor\012\Digikala\orders.csv";

DigikalaContext context = new DigikalaContext(address);

DigikalaOperation op = new DigikalaOperation(context.digikalas);

LockKeyboard lk = new LockKeyboard();